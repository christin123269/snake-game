import java.util.Random;
public class Food extends Cell {
    private GameSnake gameSnake;
    private Random random;


    public Food(GameSnake gameSnake) {      // constructor
        super(1, -1, -1, gameSnake.CELL_SIZE, gameSnake.foodColor);
        this.gameSnake = gameSnake;
        random = new Random();
    }

    public boolean isFood(int x, int y) {   // if food has x, y coordinate
        return (this.x == x) && (this.y == y);
    }

    public boolean isEaten() {              // if food is eaten or not
        return getX() == -1;
    }

    public void eat() {                     // virtual eating
        set(1, -1, -1);
    }

    public void appear() {                  // show food at new x,y coordinates
        int x, y;
        do {
            x = random.nextInt(gameSnake.CANVAS_WIDTH);
            y = random.nextInt(gameSnake.CANVAS_HEIGHT);
        } while (gameSnake.isCoordinatesBusy(x, y));
        set(1, x, y);
    }
}